module.exports = app => {
    const {router, controller} = app;
    router.all('/album/list', controller.album.list);
    router.all('/album/add', controller.album.add);
    router.all('/album/detail', controller.album.detail);
    router.all('/album/edit', controller.album.edit);
    router.all('/album/del', controller.album.del);
};