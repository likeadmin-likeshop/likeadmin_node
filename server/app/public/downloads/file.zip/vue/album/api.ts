import request from '@/utils/request'

// 相册管理列表
export function albumLists(params?: Record<string, any>) {
    return request.get({ url: '/album/list', params })
}

// 相册管理详情
export function albumDetail(params: Record<string, any>) {
    return request.get({ url: '/album/detail', params })
}

// 相册管理新增
export function albumAdd(params: Record<string, any>) {
    return request.post({ url: '/album/add', params })
}

// 相册管理编辑
export function albumEdit(params: Record<string, any>) {
    return request.post({ url: '/album/edit', params })
}

// 相册管理删除
export function albumDelete(params: Record<string, any>) {
    return request.post({ url: '/album/del', params })
}
