const moment = require('moment');

/**
 * Album 相册管理实体
 */
module.exports = app => {
    const {STRING, INTEGER, SMALLINT} = app.Sequelize

    const modelDefinition = {
        id: {
            type: int,
            autoIncrement: true,
            allowNull: false,
            field: 'id',
        },
        cid: {
            type: int,
            autoIncrement: true,
            allowNull: false,
            field: 'cid',
        },
        aid: {
            type: int,
            autoIncrement: true,
            allowNull: false,
            field: 'aid',
        },
        uid: {
            type: int,
            autoIncrement: true,
            allowNull: false,
            field: 'uid',
        },
        type: {
            type: int,
            autoIncrement: true,
            allowNull: false,
            field: 'type',
        },
        name: {
            type: string,
            autoIncrement: true,
            allowNull: false,
            field: 'name',
        },
        uri: {
            type: string,
            autoIncrement: true,
            allowNull: false,
            field: 'uri',
        },
        ext: {
            type: string,
            autoIncrement: true,
            allowNull: false,
            field: 'ext',
        },
        size: {
            type: int,
            autoIncrement: true,
            allowNull: false,
            field: 'size',
        },
        isDelete: {
            type: int,
            autoIncrement: true,
            allowNull: false,
            field: 'is_delete',
        },
        createTime: {
            type: core.TsTime,
            autoIncrement: true,
            allowNull: false,
            field: 'create_time',
        },
        updateTime: {
            type: core.TsTime,
            autoIncrement: true,
            allowNull: false,
            field: 'update_time',
        },
        deleteTime: {
            type: core.TsTime,
            autoIncrement: true,
            allowNull: false,
            field: 'delete_time',
        },
    }
    const Album = app.model.define('Album', modelDefinition , {
        createdAt: false, // 指定名字
        updatedAt: false,
        tableName: 'la_album', // 定义实际表名
    })

    return Album
}
