'use strict'

const baseController = require('../baseController')

class AlbumController extends baseController {
    async list() {
        const { ctx } = this;
        const { album } = ctx.service;
        try {
            const listReq = ctx.request.query;
            const data = await album.list(listReq);
            this.result({
                data
            })
        } catch (err) {
            ctx.logger.error(`AlbumController.list error: ${err}`);
            ctx.body = 'Internal Server Error';
            ctx.status = 500;
        }
    }

    async add() {
        const { ctx } = this;
        const { album } = ctx.service;

        try {
            const addReq = ctx.request.body;

            const data = await album.add(addReq);

            this.result({
                data
            })
        } catch (err) {
            ctx.logger.error(`AlbumController.add error: ${err}`);
            ctx.body = 'Internal Server Error';
            ctx.status = 500;
        }
    }

    async detail() {
        const { ctx } = this;
        const { album } = ctx.service;

        try {
            const id = ctx.request.query.id;

            const data = await album.detail(id);

            this.result({
                data
            })
        } catch (err) {
            ctx.logger.error(`AlbumController.detail error: ${err}`);
            ctx.body = 'Internal Server Error';
            ctx.status = 500;
        }
    }

    async edit() {
        const { ctx } = this;
        const { album } = ctx.service;

        try {
            const editReq = ctx.request.body;

            await album.edit(editReq);

            this.result({
                data: {}
            })
        } catch (err) {
            ctx.logger.error(`AlbumController.edit error: ${err}`);
            ctx.body = 'Internal Server Error';
            ctx.status = 500;
        }
    }

    async del() {
        const { ctx } = this;
        const { album } = ctx.service;

        try {
            const id = ctx.request.body.id;

            await album.del(id);

            this.result({
                data: {}
            })
        } catch (err) {
            ctx.logger.error(`AlbumController.del error: ${err}`);
            ctx.body = 'Internal Server Error';
            ctx.status = 500;
        }
    }
}

module.exports = SystemDeptController
